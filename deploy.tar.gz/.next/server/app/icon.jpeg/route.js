var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.jpeg/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_11mi_79._.js")
R.c("server/chunks/_next-internal_server_app_icon_jpeg_route_actions_1tgq139.js")
R.m(62676)
module.exports=R.m(62676).exports
