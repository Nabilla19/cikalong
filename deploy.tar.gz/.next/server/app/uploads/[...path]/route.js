var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/uploads/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__026_-_0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_uploads_[___path]_route_actions_1-sxhug.js")
R.m(83537)
module.exports=R.m(83537).exports
