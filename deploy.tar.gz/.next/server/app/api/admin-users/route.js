var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/admin-users/route.js")
R.c("server/chunks/[root-of-the-server]__0oar733._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__1u9rzs7._.js")
R.c("server/chunks/_next-internal_server_app_api_admin-users_route_actions_0_9lsk0.js")
R.m(53941)
module.exports=R.m(53941).exports
