var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/route.js")
R.c("server/chunks/[root-of-the-server]__0i9_l83._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_route_actions_17oc2ju.js")
R.m(41099)
module.exports=R.m(41099).exports
