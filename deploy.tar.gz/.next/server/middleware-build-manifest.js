globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ndvMQPlgMDg2sXyfRb6z1/_buildManifest.js",
    "static/ndvMQPlgMDg2sXyfRb6z1/_ssgManifest.js",
    "static/ndvMQPlgMDg2sXyfRb6z1/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/08ttfj81-47mu.js",
    "static/chunks/16p476t0_h1h0.js",
    "static/chunks/11be91k_gj8bl.js",
    "static/chunks/turbopack-1-5a2hs6wfyc5.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
