module.exports=[79122,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_produk-hukum_page_actions_05lytye.js.map