module.exports=[31701,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_budaya_page_actions_0rjqhrx.js.map