module.exports=[31050,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_geografi_page_actions_1pfk25l.js.map