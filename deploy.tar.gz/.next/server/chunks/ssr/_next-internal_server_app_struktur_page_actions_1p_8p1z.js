module.exports=[60901,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_struktur_page_actions_1p_8p1z.js.map