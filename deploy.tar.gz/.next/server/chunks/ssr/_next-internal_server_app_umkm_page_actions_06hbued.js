module.exports=[57014,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_umkm_page_actions_06hbued.js.map