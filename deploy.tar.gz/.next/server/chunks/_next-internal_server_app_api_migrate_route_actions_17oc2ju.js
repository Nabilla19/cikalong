module.exports=[85138,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_migrate_route_actions_17oc2ju.js.map