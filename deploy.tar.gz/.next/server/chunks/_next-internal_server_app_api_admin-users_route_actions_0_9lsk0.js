module.exports=[47063,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin-users_route_actions_0_9lsk0.js.map